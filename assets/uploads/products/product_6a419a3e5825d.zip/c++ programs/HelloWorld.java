public class HelloWorld {
    public static void main(String[] args) {

int n=10;
//upper part
for(int i =n/2; i<n; i+=2){
    for(int j =1; j<n-i; j+=2)System.out.println(" ");
    for(int j =1; j<=i; j++)System.out.println("*");
    for(int j =1; j<=n-i; j++)System.out.println(" ");
    for(int j =1; j<=i; j++)System.out.println("*");
    System.out.println(" ");

    
}
// lower part

 for(int i =n; i>=1; i--){
 for(int j =0; j<n-i; j++)System.out.println(" ");
  for(int j =1; j<i*2; j++)System.out.println("*");
  System.out.println(" ");



    }
}
}