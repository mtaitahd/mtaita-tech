#include <iostream>
#include <string>

class Person{
public:
std::string first;
std::string last;

void ptintFullName(){
    std::cout << first  <<" " << last << std::endl;
}

};
int main(){
    Person p;
    p.first ="Johnson";
    p.last  ="Mtaita";

    Person p1;
    p1.first ="Paulo";
    p1.last  ="Gabriely";
    p.ptintFullName ();
    p1.ptintFullName();

}