/*
3. Runtime Polymorphism (Using Virtual Functions & Pointers)
This happens while the program is running. The compiler does 
not know which function will be executed until the program actually runs.

To achieve this, we must use:

1.Inheritance (Parent and Child classes)

2.Virtual Functions (Using the virtual keyword in the parent class)

3.Pointers or References (To point to the child objects dynamically)

Why do we need Pointers here?
To Avoid Object Slicing: If you assign a child object to a parent variable directly
 (e.g., Parent p = Child();), C++ cuts off (slices) the child's unique properties 
 to fit into the parent box. A pointer only stores the memory address, 
 keeping the whole child object intact.

Dynamic Flexibility: A single pointer can point to different child objects 
at different times during runtime.
*/

#include <iostream>
#include <vector>
using namespace std;

// Base Class (Parent)
class Animal {
public:
    // The 'virtual' keyword enables Runtime Polymorphism.
    // It tells C++ to look for overridden versions in Child classes.
    virtual void make_sound() {
        cout << "The animal makes a generic sound." << endl;
    }
    
    // Virtual destructor is good practice when using polymorphism
    virtual ~Animal() {} 
};

// Derived Class 1 (Child)
class Cat : public Animal {
public:
    // 'override' ensures the function signature matches the parent exactly
    void make_sound() override {
        cout << "Cat says: Meow! Meow!" << endl;
    }
};

// Derived Class 2 (Child)
class Dog : public Animal {
public:
    void make_sound() override {
        cout << "Dog says: Woof! Woof!" << endl;
    }
};

int main() {
    // 1. Create instances of the child classes
    Cat my_cat;
    Dog my_dog;

    // 2. Create a Base class pointer
    // This pointer can hold the address of ANY class that inherits from Animal
    Animal* animal_ptr;

    // Point to the Cat object and execute its unique sound
    animal_ptr = &my_cat;
    animal_ptr->make_sound(); // Output: Cat says: Meow! Meow!

    // Point the SAME pointer to the Dog object
    animal_ptr = &my_dog;
    animal_ptr->make_sound(); // Output: Dog says: Woof! Woof!

    cout << "-----------------------------------" << endl;

    // 3. Advanced Power of Pointers: Creating a single List/Array of different animals
    // Without pointers, we couldn't store Cats and Dogs in the same vector.
    vector<Animal*> zoo;
    zoo.push_back(&my_cat);
    zoo.push_back(&my_dog);

    cout << "Looping through the zoo dynamically:" << endl;
    for (Animal* animal : zoo) {
        animal->make_sound(); // Each animal automatically makes its correct sound
    }

    return 0;
}