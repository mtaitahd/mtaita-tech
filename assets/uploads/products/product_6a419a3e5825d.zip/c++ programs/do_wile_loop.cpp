// do while loop = do somthing of code first
// then repeat again if condition is true

#include<iostream>
int main(){

int number;
do{
    std::cout <<"Enter the positive #: ";
    std::cin >> number;
}
while (number < 0);
std::cout <<"The # is: " << number; 

    return 0;
}