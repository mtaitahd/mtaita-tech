#include <iostream>

using namespace std;

int main()
{

    //control structure
            // if , else , else if


int age;
cout << "Enter your age" <<"\n";
cin >> age;

 if(age>=100){
    cout << "Your age is too long";
}
else if(age>=18)
{
    cout << "Your allowed to enter";
}
else if(age < 0){
    cout<< "Your not born yet";
}
else{

cout <<" your not enough to enter in this site";
}

    return 0;
}

//void no return type
/* retun  -double
         -int
         -float
         */
