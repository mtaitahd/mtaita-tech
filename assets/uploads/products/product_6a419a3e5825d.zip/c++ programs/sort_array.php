<?php


$computer = array("Hp-Pc", "Lenovo-Pc", "Dell-Pc", "Toshiba-Pc"); 


sort($computer); 

print_r($computer);

?>