#include <iostream>
#include <string>
using namespace std;
class Person{
    private:
  string first;
  string last;

 public:

  void setFirstName(string first){
    this->first = first;

  }
  void setLastName(string last){
    this->last = last;
  }
  void printFullName(){
   cout << first <<" " << last <<endl;
  }
   string getFullName(){
    return first + " " + last;
  }
  };
int main(){
 Person p;
 p.setFirstName ("Johnson");
 p.setLastName ("Mtaita");
cout << p.getFullName () <<endl;
     return 0;

}

