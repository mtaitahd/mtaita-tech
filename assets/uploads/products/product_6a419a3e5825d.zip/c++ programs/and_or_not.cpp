#include <iostream>

//&& = check if two condition are true
//!! =check if at least one of two condition is true
// ! = reverse the logical state of its operand
int main(){
int temp;
std::cout <<"Enter temperature";
std::cin >>temp;

if (temp > 0 && temp < 30){

    std::cout <<"The temperature";
}
else{
    std::cout <<"The temperature is bad";
}

    return 0;
}