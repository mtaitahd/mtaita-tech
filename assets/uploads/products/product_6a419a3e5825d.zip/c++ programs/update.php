<?php
$conn = new mysqli("www.mocu.ac.tz", "mocu_2025", "mocu@2015", "DAM");

// Check if update button was clicked
if (isset($_POST['update'])) {
    $id = $_POST['sn'];
    $name = $_POST['name'];
    $age = $_POST['age'];

    $sql = "UPDATE staff SET Name='$name', Age='$age' WHERE Sn=$id";
    
    if ($conn->query($sql) === TRUE) {
        header("Location: index.php");
    } else {
        echo "Error updating: " . $conn->error;
    }
}

// Fetch existing data to populate the form
$id = $_GET['id'];
$result = $conn->query("SELECT * FROM staff WHERE Sn=$id");
$row = $result->fetch_assoc();
?>

<form method="POST" action="update.php">
    <input type="hidden" name="sn" value="<?php echo $row['Sn']; ?>">
    <label>Name:</label>
    <input type="text" name="name" value="<?php echo $row['Name']; ?>">
    <label>Age:</label>
    <input type="number" name="age" value="<?php echo $row['Age']; ?>">
    <input type="submit" name="update" value="Save Changes">
</form>