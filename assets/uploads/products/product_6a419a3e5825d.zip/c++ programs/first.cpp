#include <iostream>
int main(){


    // two style of putting  end of the statement 
    // first is << std::endl
    std::cout <<"i like simba" << std::endl;
    std::cout <<"its real good" <<'\n';
    std::cout <<"its so nice to hear that";

    return 0;
}