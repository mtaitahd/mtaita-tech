#include <iostream>

using namespace std;
class Person{
private:
    int age ;


public:
    void setAge(int age){

    this-> age = age;
    }
    int getAge(){
    return age;
    }

    void calculate(){
    cout<< "enter first number"<<endl;
    int num1, num2;
    std::cin >> num1;
    cout <<"enter second number"<<endl;

    std::cin >> num2;
    int sum = num1+num2;
    cout<<"the sum of num2 and num2 is :" <<sum <<endl;

    }
};
int main()
{
    Person person;
    person.setAge(12);
    cout <<person.getAge()<<endl;
    person.calculate();
    return 0;
}
