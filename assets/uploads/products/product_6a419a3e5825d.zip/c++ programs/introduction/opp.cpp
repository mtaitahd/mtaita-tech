// what is encapsulation process of hiding data(attributes) using private and protected acess
// what is polmorphism one intrface, many implementations , same function name  behaves differently contexs
// what is inheritance a child derives properties and behavious  from a parent (base) class
// promotes code reuse
// what is abstract hinding complex implementation details and showing only essential
// fetures to the user


// applications of c++
//1. gaming developments
//2. operating systemn buildings(window kernel)
//3.embeded system
//4.databases
//5.mobile applications
//6.ai & machine lerning