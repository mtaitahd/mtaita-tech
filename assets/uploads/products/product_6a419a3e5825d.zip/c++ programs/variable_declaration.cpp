//local variable = declared inside a function or block{}
//Global variable = declared outside of all functions
//::scope resolution if u neeed to use global instead of local

#include<iostream>
 int myNum =3;
void prinNum();
int main(){
int myNum =1;
prinNum();
std::cout << ::myNum <<'\n';
 
    return 0;
}
void prinNum(){
    int myNum =2;
    std::cout << ::myNum <<'\n';
}