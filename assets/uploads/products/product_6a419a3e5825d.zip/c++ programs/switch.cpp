#include <iostream>
int main(){
//switch = alternative to using  many "else if "statement
// compare one value against matching cases
int month;
std::cout <<"Enter the month (1-12): "<<"\n" ;
std::cin >> month;
switch(month){
    case 1:
    std::cout <<"its january";
    break;
     case 2:
    std::cout <<"its February";
    break;
     case 3:
    std::cout <<"its march";
    break;
     case 4:
    std::cout <<"its April";
    break;
     case 5:
    std::cout <<"its May";
    break;
     case 6:
    std::cout <<"its June";
    break;
     case 7:
    std::cout <<"its Julai";
    break;
     case 8:
    std::cout <<"its August";
    break;
     case 9:
    std::cout <<"its September";
    break;
     case 10:
    std::cout <<"its October";
    break;
     case 11:
    std::cout <<"its November";
    break;
     case 12:
    std::cout <<"its December";
    break;
    default:
    std:: cout <<"Please enter  in only  numbers(1-12)";
}
    return 0;
}