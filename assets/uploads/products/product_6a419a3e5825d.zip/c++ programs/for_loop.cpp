//for loop = is loop that excute block of code in specified 
//amount of time
#include<iostream>
int main(){
/*for(int i = 1; i<=10; i++){
    std::cout << i <<'\n';
}
std::cout <<"Happy new Year\n";
    return 0;

}
// count backward i>=0; i--

*/

// Break = break out of loop
//continue = skip current iteration

for(int i=1; i<=20; i++){
    if(i ==13){
        break;
    }
    std::cout << i <<'\n';
}
}