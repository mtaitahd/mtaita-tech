/*
1. Introduction to Polymorphism
The word Polymorphism comes from Greek, meaning "many forms" (poly = many, morph = form). In C++,
 it allows different objects to respond to the same 
 function call in their own unique way.

There are two main types of polymorphism in C++:

Compile-Time Polymorphism (Static / Early Binding)

Runtime Polymorphism (Dynamic / Late Binding)

2. Compile-Time Polymorphism (Function Overloading)
This happens during the compilation of the program. The compiler knows exactly which function to call base
*/
#include <iostream>
using namespace std;

class Calculator {
public:
    // Function 1: Takes two integers
    int add(int a, int b) {
        return a + b;
    }

    // Function 2: Takes three integers (Same name, different parameters)
    int add(int a, int b, int c) {
        return a + b + c;
    }
};

int main() {
    Calculator calc;

    // Compiler knows to call Function 1 because we passed 2 arguments
    cout << "Sum of 2 numbers: " << calc.add(10, 20) << endl;

    // Compiler knows to call Function 2 because we passed 3 arguments
    cout << "Sum of 3 numbers: " << calc.add(10, 20, 30) << endl;

    return 0;
}