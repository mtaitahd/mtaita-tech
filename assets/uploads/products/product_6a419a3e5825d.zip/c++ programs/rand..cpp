#include<iostream>
int main(){
    srand(time(0));
    int num = rand() % 3 + 1;
    std::cout << num;
return 0;
}