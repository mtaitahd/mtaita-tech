//usefull string method

#include <iostream>
int main(){

std::string name;
std::cout <<"Enter your name: ";
std::getline(std::cin , name);
if(name.length() > 12){
    std::cout <<"Your name can't be over 12 chracter";

}

//if (name.empty()){ if enter empty but if you need to clear 
// name.clear() futa jina
//append  unganisha jinaa
// name.append()
// rudisha character kulingana na position
//name.at(1)
//ku insert insert(1, "@");
//kutafuta position name.find('');
//std::cout <<"you didn't enter your name";
//name.erase(0,3);
//} 
else {
    std::cout <<"Welcome  " << name;

}


    return 0;
}