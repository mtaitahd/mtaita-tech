#include<iostream>
int main(){

std::string questions[] = {"1. What year was c++ created: ",
                           "2.Who is invested c++?: ",
                           "3.What is the predecessor of c++?: ",
                           "4.Is the Earth flat?: "};


std::string options[][4] ={{"A. 1969", "B.1975","C.1985","D.1989"},
                          {"A.Guido van Rossum","B.Bjarne Stroustrup","C.John Carmack","D.Mark Zuckerburg"},
                          {"A.c","B.c+","C--","D.B++"},
                          {"A.yes","B.no", "C.sometimes","D.What's Earth?"}};


                char answerKey[] ={'C','B','A','B'};
                      int size = sizeof(questions)/sizeof(questions[0]);  
                      char guess;
                      int score;
                      for(int i= 0; i < size;  i++ ) {
                        std::cout << "***********************\n";
                        std::cout << questions [i] << '\n';
                        std::cout << "***********************\n";
                      for(int j = 0; j < sizeof(options[i])/sizeof(options[i][0]); j++){
                        std::cout << options[i][j] << '\n';
                      } 
                      std::cin >>guess;
                      guess = toupper(guess);
                      if(guess ==answerKey[i]){
                        std::cout << "correct!\n";
                        score++;
                      }else{
                        std::cout << "wrong!\n";
                        std::cout << "Answer: "<< answerKey[i] << '\n';

                      }
                    
                      }   
                 std::cout << "********************\n";
                 std::cout << "       RESULT      \n";
                 std::cout  << "********************\n";
                 std::cout << "Correct Guesses: " << score <<'\n';
                 std::cout << "# of Questuions: " <<size << '\n';
                 std::cout << "score: " << (score/(double)size)*100 << "%";




    return 0;
}