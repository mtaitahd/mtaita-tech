#include<iostream>
using namespace std;

class Mtu{
  public:
 virtual void onyeshaWajibu() = 0;

 virtual ~Mtu() {} 

};

class Mwanafunzi : public Mtu{
 public:
   void onyeshaWajibu() override{
   cout <<"Wajibu wangu ni Kusoma na kufanya mitihani!"<< endl;

   }



};
class Mwalimu : public Mtu{
  public:
   void onyeshaWajibu() override{
    cout << "Wajibu wangu ni Kufundisha na kusahihisha!" <<endl;
   }

};

int main(){

Mtu* bothptr;
Mwanafunzi mwanafunzi;
Mwalimu mwalimu;


bothptr = &mwanafunzi;
bothptr->onyeshaWajibu();
bothptr = &mwalimu;
bothptr->onyeshaWajibu();

    return 0;
}