#include <iostream>
using namespace std;

class Mzazi {
public:
    void ujumbe() {
        cout << "Mimi ni Mzazi!" << endl;
    }
};

class Mtoto : public Mzazi {
public:
    void ujumbe() {
        cout << "Mimi ni Mtoto!" << endl;
    }
};

int main() {
    Mzazi* ptr; // Pointer ya Mzazi
    Mtoto objMtoto; // Object ya Mtoto
    
    ptr = &objMtoto; // Pointer inaashiria kwa Mtoto
    
    ptr->ujumbe(); // MATOKEO: "Mimi ni Mzazi!" (Hii ni shida!)
    return 0;
}