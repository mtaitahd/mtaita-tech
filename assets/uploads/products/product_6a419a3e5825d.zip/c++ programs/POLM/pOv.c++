#include <iostream>
using namespace std;
class OperatingSystem {
public:
    virtual void displayInfo() {
        cout << "This is a generic operating system." << endl;
    }
};

class Windows : public OperatingSystem {
public:     

   virtual void displayInfo() override {
        cout << "This is Windows OS." << endl;
    }
};   