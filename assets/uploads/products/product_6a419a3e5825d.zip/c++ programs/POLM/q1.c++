#include<iostream>
using namespace std;


class NjiaYaMalipo{
  public:
    virtual void lipa(){
      cout << "malipo ya kawaida yanaanzaa.."<<endl;

    }


};

class TigoPesa : public NjiaYaMalipo{
  public:
     void lipa() override{
     cout<< "Malipo yamefanyika kwa TigoPesa!" <<endl;

     }


};
class AzaPay : public NjiaYaMalipo{
    public:
 void lipa()override {
cout <<"Malipo yamefanyika kwa AzaPay!"<<endl;
 }
};

int main(){
 NjiaYaMalipo* roadptr;
 
 TigoPesa  tigopesa;
 AzaPay azampay;

 roadptr = &tigopesa;
 roadptr->lipa();

roadptr = &azampay;
 roadptr->lipa();




    return 0;
}