#include <iostream>
using namespace std;

// 1. ABSTRACT CLASS (Huwezi kutengeneza object hapa)
class NjiaYaMalipo {
public:
    // Hii sasa ni Pure Virtual Function
    // Haina mabano ya { } bali inawekwa = 0;
    virtual void lipa() = 0;

    // Ni tabia nzuri kuweka virtual destructor kwenye abstract class
    virtual ~NjiaYaMalipo() {}
};

// 2. CLASS ZA WATOTO (Lazima ziandike kodi ya lipa(), vinginevyo kutakuwa na ERROR)
class TigoPesa : public NjiaYaMalipo {
public:
    void lipa() override {
        cout << "Malipo yamefanyika kwa TigoPesa!" << endl;
    }
};

class AzaPay : public NjiaYaMalipo {
public:
    void lipa() override {
        cout << "Malipo yamefanyika kwa AzaPay!" << endl;
    }
};

int main() {
    // JARIBIO LA KUKATAZWA:
    // NjiaYaMalipo malipo; // Hii iko COMMENT kwa sababu C++ itagoma (Error: cannot declare variable of abstract type)

    // LAKINI POINTER INARUHUSIWA!
    NjiaYaMalipo* roadptr;

    TigoPesa tigopesa;
    AzaPay azampay;

    // Matumizi ya pointer kubadilika (Polymorphism) yanabaki vilevile
    roadptr = &tigopesa;
    roadptr->lipa(); // Output: Malipo yamefanyika kwa TigoPesa!

    roadptr = &azampay;
    roadptr->lipa(); // Output: Malipo yamefanyika kwa AzaPay!

    return 0;
}