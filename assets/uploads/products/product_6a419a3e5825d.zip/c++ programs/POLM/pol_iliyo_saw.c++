#include <iostream>
using namespace std;


class Simu {
public:
    
    virtual void washaSimu() {
        cout << "Simu ya kawaida inawaka..." << endl;
    }
};


class iPhone : public Simu {
public:
    
    void washaSimu() override {
        cout << "iPhone inawaka... Nembo ya Apple inatokea!" << endl;
    }
};


class Samsung : public Simu {
public:
    void washaSimu() override {
        cout << "Samsung inawaka... Nembo ya Android inatokea!" << endl;
    }
};

int main() {
   
    Simu* remoti; 

  
    iPhone simuYanguYaKwanza;
    Samsung simuYanguYaPili;

   
    remoti = &simuYanguYaKwanza; // Tunachukua anwani (&) ya iPhone
    remoti->washaSimu();         // Runtime inaona kuna iPhone, Inatoa: Nembo ya Apple!

    // HATUA YA 2: Weka remoti ile ile kwenye Samsung
    remoti = &simuYanguYaPili;   // Tunabadilisha anwani, sasa inaangalia Samsung
    remoti->washaSimu();         // Runtime inaona kuna Samsung, Inatoa: Nembo ya Android!

    return 0;
}