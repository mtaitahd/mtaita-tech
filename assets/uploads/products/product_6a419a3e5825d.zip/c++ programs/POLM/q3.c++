#include<iostream>
using namespace std;


class  Umbile{
public:
virtual void tafutaEneo()= 0;

virtual ~Umbile() {}

};
class Duara : public Umbile{
    public:
double radius;
 Duara(double radius){

    this->radius = radius;
 }
 void tafutaEneo() override {
    double eneo = 3.14 *(radius*radius);
 
 cout << "Eneo la Duara ni: " << eneo <<endl;
 }
};

class Mstatili : public Umbile{
public:
 double urefu, upana ;
 Mstatili(double urefu, double upana){
    this-> urefu = urefu;
    this->upana = upana;
 }
 void tafutaEneo() override {

    double eneo = urefu * upana;
    cout << "Eneo la Mstatili ni: "<< eneo << endl;
 }

 
};
int main(){

Umbile* wote;

Duara duara(2);
Mstatili mstatili(3,5);

wote = &duara;
wote->tafutaEneo();
wote =&mstatili;
wote->tafutaEneo();
    return 0;
}