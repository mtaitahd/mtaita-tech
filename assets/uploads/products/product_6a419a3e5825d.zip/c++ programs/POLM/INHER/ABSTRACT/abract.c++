#include <iostream>
using namespace std;

/*
 * ============================================================================
 * DEFINITION:
 * An Abstract Class in C++ is a class that is designed to be used solely 
 * as a base class (blueprint). It cannot be instantiated (you cannot create 
 * an object of it). It is used to provide a common interface for its 
 * derived classes.
 *
 * CHARACTERISTICS:
 * 1. Pure Virtual Functions: It must contain at least one pure virtual function.
 * 2. No Instantiation: You cannot create an object (e.g., 'Shape s;') of it.
 * 3. Mandatory Implementation: Derived classes MUST provide an implementation 
 *    for all pure virtual functions, otherwise they also become abstract.
 * 4. Pointers/References: You CAN create pointers or references of an 
 *    abstract class to achieve polymorphism.
 * 5. Can have Concrete Members: It can still have data members, constructors, 
 *    and normal (non-virtual) functions.
 * ============================================================================
 */

class AbstractBase {
public:

    virtual void showDefinition() = 0;

   
    void showCharacteristics() {
        cout << "1. Contains at least one pure virtual function." << endl;
        cout << "2. Cannot be instantiated." << endl;
        cout << "3. Acts as a blueprint for derived classes." << endl;
    }
};

class ConcreteDerived : public AbstractBase {
public:
    void showDefinition() override {
        cout << "Definition: An Abstract class provides a common interface." << endl;
    }
};

int main() {
   
    
    ConcreteDerived obj;
    obj.showDefinition();
    obj.showCharacteristics();

    return 0;
}