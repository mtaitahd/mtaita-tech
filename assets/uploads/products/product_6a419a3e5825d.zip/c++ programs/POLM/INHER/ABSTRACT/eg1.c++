#include <iostream>
#include <string>
using namespace std;

/**
 * ABSTRACT CLASS: PaymentMethod
 * This acts as the blueprint for any payment service.
 */
class PaymentMethod {
public:
    // Pure virtual function: Every payment method must process a payment differently
    virtual void processPayment(double amount) = 0;

    // A common function all payment methods share
    void printReceipt(double amount) {
        cout << "Receipt: Successfully processed payment of $" << amount << endl;
    }
};

// Derived Class 1: Credit Card
class CreditCard : public PaymentMethod {
public:
    void processPayment(double amount) override {
        cout << "Processing Credit Card payment of $" << amount << " via bank gateway." << endl;
    }
};

// Derived Class 2: PayPal
class PayPal : public PaymentMethod {
public:
    void processPayment(double amount) override {
        cout << "Processing PayPal payment of $" << amount << " using email authentication." << endl;
    }
};

int main() {
    // We can use a base class pointer to point to different payment types
    PaymentMethod* myPayment;

    // User chooses Credit Card
    myPayment = new CreditCard();
    myPayment->processPayment(150.00);
    myPayment->printReceipt(150.00);

    cout << "-----------------------------" << endl;

    // User switches to PayPal
    delete myPayment;
    myPayment = new PayPal();
    myPayment->processPayment(85.50);
    myPayment->printReceipt(85.50);

    delete myPayment;
    return 0;
}