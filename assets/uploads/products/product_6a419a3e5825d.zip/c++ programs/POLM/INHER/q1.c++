#include<iostream>
using namespace std;

class SimuYaZamani{
    
protected:
 bool uwezo_wa_kupiga = true;

};
class SimuYaMkononi : public SimuYaZamani{
protected:
bool uwezo_wa_sms = true;

};

class SmartPhone : public SimuYaMkononi {
public:
void angaliaSifa(){
cout<<"Simu ya zamani inauwezo wa kutuma sms: "<< uwezo_wa_sms<<endl;
cout <<"Simu ya mkononi inauwezo wa kupiga: "<<uwezo_wa_kupiga<<endl;
}


};

int main(){
SmartPhone smartPhone;
smartPhone.angaliaSifa();

}