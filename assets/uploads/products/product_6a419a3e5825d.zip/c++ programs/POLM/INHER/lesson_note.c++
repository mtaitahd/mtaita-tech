/*
================================================================================
                         C++ OOP LESSONS SUMMARY NOTES
================================================================================

--------------------------------------------------------------------------------
LESSON 1: POLYMORPHISM
--------------------------------------------------------------------------------
The concept of having a single entity (a function or an operator) behave 
differently depending on the context in which it is used.

1. Compile-Time Polymorphism (Static)
   - Resolved during the compilation phase.
   - Primary mechanism: Function Overloading (Functions sharing the exact same 
     name but having different parameter types or counts within the same class).

2. Runtime Polymorphism (Dynamic)
   - Resolved while the program is actively running.
   - Achieved by combining Inheritance, Virtual Functions, and Pointers.


--------------------------------------------------------------------------------
LESSON 2: VIRTUAL FUNCTIONS & POINTERS IN RUNTIME POLYMORPHISM
--------------------------------------------------------------------------------
Combining these two tools allows your code to adapt its behavior dynamically 
at runtime without losing specific object data.

- Virtual Function: The 'virtual' keyword tells the compiler to delay its 
  decision-making process (known as Late Binding). It grants permission for 
  a Derived (Child) Class to overwrite ('override') the Parent Class's 
  implementation.
- Pointer (*): Acts like a "Universal Remote Control". It does not allocate 
  memory for a new object itself; instead, it holds the memory address (&) 
  of a child object.
- Object Slicing: Without using a pointer, assigning a child object to a parent 
  variable causes C++ to literally "slice off" the extra child properties to 
  fit the parent container. Using a pointer prevents this because it references 
  the entire object where it sits in memory.


--------------------------------------------------------------------------------
LESSON 3: ABSTRACT CLASSES & PURE VIRTUAL FUNCTIONS
--------------------------------------------------------------------------------
An architectural design pattern used to enforce strict rules and structure 
across your inheritance tree.

- Pure Virtual Function: A virtual function that has no body/implementation 
  in the base class. It is declared by assigning it to zero: 
  virtual void doWork() = 0;
- Abstract Class: Any class that contains at least one Pure Virtual Function.
  * The Golden Rule: You cannot instantiate (create a regular object of) an 
    Abstract Class. However, you are allowed to create a pointer of its type.
  * It legally forces every single child class to override that specific function. 
    If a child class forgets to implement it, the code throws a compilation error.


--------------------------------------------------------------------------------
LESSON 4: INHERITANCE & ACCESS SPECIFIERS
--------------------------------------------------------------------------------
The mechanism that allows a New Class (Child/Derived) to adopt the attributes 
and behaviors of an Existing Class (Parent/Base), eliminating code duplication 
and maximizing reusability.

Access Specifiers (Data Protection):
- public: Accessible by everyone (inside the class, by child classes, and 
  from external blocks like main()).
- protected: Accessible only within the parent class and its child classes 
  (Derived classes). External blocks like main() are completely blocked.
- private: Strictly confidential to the parent class. Neither child classes 
  nor external blocks can see or touch it.

Core Types of Inheritance Covered:
1. Single Inheritance: One child class inherits directly from exactly one 
   parent class.
2. Multilevel Inheritance: A chain of inheritance (Grandparent -> Parent -> Child). 
   The child at the bottom inherits access all the way up to the Grandparent's 
   protected members.
3. Multiple Inheritance: A single child class inherits properties from more than 
   one parent class simultaneously (e.g., class Child : public Father, public Mother).

Order of Execution (Lifecycles):
- During Creation (Constructor): The Parent constructor executes first 
  -> followed by the Child constructor.
- During Destruction (Destructor): The Child destructor executes first 
  -> followed by the Parent destructor (Strict reverse order).

================================================================================
*/