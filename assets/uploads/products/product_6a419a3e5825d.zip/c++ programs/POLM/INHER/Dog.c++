#include<iostream>
using namespace std;

 class Animal{
  protected:
   string name = "Ngoma";
  int numberOfLegs = 4;
};
class Dog: public Animal{
   public: 
  void inh(){
    cout << name<<endl;
    cout << numberOfLegs<<endl;
  }

};
class Cat : public Dog{
public:
void nyumbn(){
    cout << name <<endl;
    cout << numberOfLegs<< endl;
}

}; 
int main(){
    
  Dog dog;
  Cat cat;
  
  dog.inh();
  cat.nyumbn();

    return 0;
}