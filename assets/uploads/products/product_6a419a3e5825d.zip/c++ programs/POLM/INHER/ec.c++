#include<iostream>
using namespace std;
class Person{
private:
string  name;

public:
void setName(string n){
name=n;

}
string  getName(){
    return name;
}

};

int main (){
Person p;
p.setName("Swalha");

cout <<p.getName();
    return 0;
}