#include <iostream>
using namespace std;

// 1. CLASS YA BABU (BASE CLASS)
class Babu {                            
protected:
    string jinaLaUkoo = "Mtaita"; // Inarithiwa kwenda chini
};


// 2. CLASS YA BABA (DERIVED CLASS YA BABU)
class Baba : public Babu {
protected:
    double kiwanjaChaFamilia = 2.8;
     // Hekari 2 za kiwanja
};

// 3. CLASS YA MTOTO (DERIVED CLASS YA BABA)
class Mtoto : public Baba {

    void onyeshaUrithi() {
        // Mtoto anaweza kuona vitu vya Baba na vya Babu kupitia Multilevel Inheritance
        cout << "Jina la Ukoo: " << jinaLaUkoo << endl;
        cout << "Mali niliyorithi: Hekari " << kiwanjaChaFamilia << " za kiwanja." << endl;
    }
};

int main() {
    Mtoto mwanafamilia;
    //mwanafamilia.onyeshaUrithi();
    return 0;
}