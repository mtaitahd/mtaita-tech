#include <iostream>
using namespace std;


class Coding {
protected:
    string lugha = "C++";
};


class Graphics {
protected:
    string programu = "Adobe Photoshop";
};


class MtaitaTech : public Coding, public Graphics {
public:

void onyeshaKazi() {
        cout << "Mimi huku natumia: " << lugha << " kuandika mifumo." << endl;
        cout << "Na huku natumia: " << programu << " kutengeneza Logo." << endl;
    }
};

int main() {
    MtaitaTech kampuni;

    kampuni.onyeshaKazi();
    return 0;
} 