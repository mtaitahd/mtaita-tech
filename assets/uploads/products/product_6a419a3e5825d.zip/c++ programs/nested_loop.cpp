//nested loop is loop inside of loop
#include<iostream>
int main(){
/* for(int j =1 ; j<=3; j++){
for(int i = 1; i<=10; i++){
    std::cout << i <<' ';
}
std:: cout <<'\n';
}
    return 0;
}*/
 int rows;
 int  colums;
 char symbol;
 std::cout <<"How many rows: ";
 std::cin >> rows;
 std::cout <<"How many colums: ";
 std::cin >> colums;
 std::cout <<"Enter s symbol to use: ";
 std::cin >> symbol;
  for(int j =1 ; j<=rows; j++){
for(int i = 1; i<=colums; i++){
    std::cout << symbol <<' ';
}
std:: cout <<'\n';
}
    return 0;
}