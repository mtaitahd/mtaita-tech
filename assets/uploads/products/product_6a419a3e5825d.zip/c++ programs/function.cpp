#include <iostream>

 void happyBithday(std::string name , int age);

int main(){
// function = is block of reusable code
 std::string name ="Mtaita HD";
 int age =22;
    
  happyBithday(name,age);
  return 0;
}
void happyBithday(std::string name, int age){
    
    std::cout<<"Happybithday to: "<< name << std::endl;
    std::cout<<"Happybithday to you: " << name << std::endl;
    std::cout<< "Your age is: "<< age;
}