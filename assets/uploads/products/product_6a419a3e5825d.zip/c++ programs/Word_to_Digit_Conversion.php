<?php


$input = "zero; three; five; six; eight; one"; 

$words = explode("; ", $input);

$map = ["zero"=>'0', "one"=>'1', "three"=>'3', "five"=>'5', "six"=>'6', "eight"=>'8'];

foreach ($words as $word) { echo $map[$word]; } 

?>