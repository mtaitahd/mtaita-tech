//foreach loop = loop that eases the traversal over
// an iterable data set
#include<iostream>
int main(){
std::string students [] ={"Johnson","Juma","Fatma","Angela"};


for(std::string student : students){
    std::cout << student << '\n';
}
    return 0;
}
