#include<iostream>
int main(){
// if statement = do something if a condition is true if not, then don't do it,

int age ;
std::cout <<"enter your age:";
std::cin >>age;
if(age>=100){
  std::cout <<"Your are too old big to enter this site! ";
  
}
else if(age>=18){
    std::cout <<"Welcome to the site!"; 
}
else if(age < 0){
    std::cout <<"Your not been born yet!";
}

else{
    std::cout <<"Your not enough to enter!";
}
    return 0;
}