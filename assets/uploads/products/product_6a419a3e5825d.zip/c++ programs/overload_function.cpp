#include<iostream>
void bakeMakande();
void bakeMakande(std::string tunda);
int main(){

bakeMakande("Parachichi");

    return 0;
}
void bakeMakande(){
    std::cout <<"Here is your Makande! \n";
}
void bakeMakande(std::string tunda){
    std::cout <<"Here is your Makande with "<< tunda;

}

//note: function name + parametere is function signature
