#include <iostream>
using namespace std;
class Employee{

private:
string salary;

public:
void setSalary(string s){ // setter => to set private data
    if(s>0){
        salary = s;
    }
else{
    cout << "Invalid salary" <<endl;
}

int getSalary(){ // getter => to access private data
    return salary;

};
int main(){
Employee e;

e.setSalary(50000);
cout << "Salary: " << e.getSalary() << endl;
return 0;
}