#include <iostream>

int main(){
    
int bithYear ;
int yourYear;
int const keep1 = 789;
int const keep2 = 1236;
std:: cout << "Enter Your Year" <<"\n";
std:: cin >> bithYear;
int pYear = keep1 - bithYear + keep2;
std:: cout <<"Your bithYear is :" << pYear;
    return 0;
}