#include<iostream>
int main(){
//array = a data structure that can hold multiple value
// values are accessed by an index number
// "kind of like a variable that holds multiple values"
 
std::string car[] ={"Toyota","Range","Mustang"};


for(int i=0; i<3; i++){
    std::cout << car[i] << '\n';
}





    return 0;
}