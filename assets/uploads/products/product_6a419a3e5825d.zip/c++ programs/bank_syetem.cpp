#include<iostream>
#include<iomanip>

void showBalance(double balance);
double deposit();
double withdraw(double balance);

int main(){
    double balance =0.00;
    int choice = 0;
    do{

    std::cout <<"***************\n";
    std::cout <<"\n";
    std::cout <<"Enter your choice :\n";
    std::cout <<"***************\n";
    std::cout <<"\n";
    std::cout <<"1. show Balance\n";
    std::cout <<"2. Deposit Money\n";
    std::cout <<"3. withdraw Money\n";
    std::cout <<"4. Exit\n";
    std::cin >> choice;
    std::cin.clear();
    fflush(stdin);

switch(choice){
        case 1:showBalance (balance);
               break;
        case 2:balance += balance + deposit();
               showBalance(balance);
               break;
        case 3:balance -=withdraw(balance);
               showBalance(balance);
               break;
        case 4:std::cout << "Thanks for visiting!\n";
              break;
         default:std::cout <<"Invalid choices \n";


    }
}
while(choice != 4);
    return 0;
}
void showBalance(double balance){
   std::cout << "Your balance is : Tsh "<<std::setprecision(2) <<std::fixed << balance <<std::endl;
}
double deposit(){

double amount =0;
   std::cout<<"Enter amount to be deposited: "<<std::endl;
   std::cin >>amount ;

   if(amount > 0){

    return amount;
   }
   else{
    std::cout<<"That's was not a valid amount"<<std::endl;
    return 0;
   }

}
double withdraw(double balance){
     double amount =0;
     std::cout<< "Enter amount to be withdraw\n";
     std::cin >>amount;

     if(amount >balance){
        std::cout<<"insufficient balance\n";
        return 0;
     }
    else if(amount < 0){
        std::cout<<"That's was not valid  amount.\n";
        return 0;
     }
     else{
        return amount;
     }
    return 0;
}
