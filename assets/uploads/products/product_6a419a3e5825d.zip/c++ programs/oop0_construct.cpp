#include <iostream>
#include <string>

class Person {
private:
 std::string first;
 std:: string last;

 public:
 Person(std::string first, std::string last): first(first), last (last) {
 }
 Person() = default; //default constructor
 
 void setFirstName(std:: string first){
    this-> first = first;
 }
void setLastName (std::string last){
    this-> last = last;
}
/*
void printFullName(){
    std::cout << first << " " << last << std::endl;
}*/
 std:: string getFullName (){
    return first + " " + last ;
 }
};
int main(){
    Person p("Johnson","Mtaita");
    // p.printFullName();

       std::cout << p.getFullName() <<std::endl;
    return 0;
}