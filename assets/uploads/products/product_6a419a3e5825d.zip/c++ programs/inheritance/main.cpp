#include <iostream>

using namespace std;

class Person{
std::string fName;
std::string  lName;



public:
    Person(std::string fName , std::string lName): fName(fName), lName(lName){
    }
     void setfName(std::string fName){
     this->fName = fName;
     }
     std:: string getFName(){
     return fName;
     }
     void setlName(std::string lName){
     this->lName = lName;
     }
     std::string getLName(){
     return lName;
     }
};
class Employee: public Person{
    std:: string department;
    public:
    Employee(std::string fName, std::string lName, std:: string department): Person(fName,lName), department(department){}


    void printInfo(){
    cout<< "fullName is: "<< getFName() << " " << getLName() << endl;
    cout << "Department is: " << department << endl;
    }
};

int main()
{
Employee e("Johnson","Mtaita","IT");
  e.printInfo();

    return 0;
}
