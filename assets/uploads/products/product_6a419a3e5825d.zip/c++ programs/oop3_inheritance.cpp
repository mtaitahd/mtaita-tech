#include <iostream>
#include <string>

class Person{
    private:
    std::string first;
    std::string last;

    public:
    Person(std::string first, std:: string last): first(first), last(last){}

    void setFirstName(std:: string first){
        this-> first = first;
    }
    void setLastName(std:: string last){
        this-> last =last;
    }
    std:: string getFullName(){
        return first +" " +last;
    }
    void printFullName(){
        std::cout << first <<" "<< last <<std::endl;
    }
};
class Employee: public Person {
    std::string department;
    public:
    Employee(std:: string first, std:: string last, std:: string department): Person(first,last),department(department){}

    std:: string getDepartment(){
        return department;
    }
   void setDepartment(std:: string department){
    this-> department = department;
   }
   void printInfo(){
    std::cout <<"name: " << getFullName() <<std::endl;
    std::cout <<"Department: "<< getDepartment(); 
   }
};

int main(){
    Employee e("Johnson","Mtaita","sales");
    e.printInfo();
    

    return 0;
}