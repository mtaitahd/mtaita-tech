#include<iostream>
int main(){
// sizeof() = determines the size in bytes of a:
// variable, data type, class, objects etc.
std::string name = "Johnson";
double gpa = 2.5;
char wape[] ={'a','b','c','d'};
std::string letter ="Welcome Johnson";
char grade ='A';
bool student = true;
std::cout << sizeof(student) << " Bytes\n";
std::cout << sizeof(gpa) << " Bytes\n";
std::cout << sizeof(letter) << " Bytes\n";
std::cout << sizeof(name) << " Bytes\n";
std::cout << sizeof(grade) << " Bytes\n";
std::cout << sizeof(wape) << " Bytes\n";


    return 0;
}