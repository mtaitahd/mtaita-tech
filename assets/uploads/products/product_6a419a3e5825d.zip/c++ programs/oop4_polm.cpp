#include <iostream>
#include <string>
#include <vector>

class Person{
    protected:
    std::string first;
    std::string last;

    public:
    Person(std::string first, std:: string last): first(first), last(last){}

    void setFirstName(std:: string first){
        this-> first = first;
    }
    void setLastName(std:: string last){
        this-> last =last;
    }
    std:: string getFullName(){
        return first +" " +last;
    }
    void printFullName(){
        std::cout << first <<" "<< last <<std::endl;
    }
    virtual  void printInfo() {
    std::cout <<"first: " << first <<std::endl;
    std::cout <<"last: "<< last <<std::endl; 
   }
   static void printPeople(std::vector<Person*>people){
    for(auto person: people){
        person->printInfo();

    }
    
   }
};
class Employee: public Person {
    std::string department;
    public:
    Employee(std:: string first, std:: string last, std:: string department): Person(first,last),department(department){}

    std:: string getDepartment(){
        return department;
    }
   void setDepartment(std:: string department){
    this-> department = department;
   }
   void printInfo() override{
    std::cout <<"first: " << first <<std::endl;
    std::cout <<"last: " << last <<std::endl;
    std::cout <<"Department: "<< department <<std::endl;
   }
};

int main(){
     std::vector<Person*> people; // use star to get all user information
     Person p("meshack","Paulo");
    Employee e("Johnson","Mtaita","sales");
    //e.printInfo();
    
    people.push_back(&p);
    people.push_back(&e);
    // loop to retrive all information to both person
    //for(auto person: people){
   //     person->printInfo();
   // }
   Person::printPeople(people);
    return 0;
}