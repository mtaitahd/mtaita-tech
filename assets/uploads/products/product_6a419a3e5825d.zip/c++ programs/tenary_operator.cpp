#include<iostream>
//tenary operator ?: = replacement to an if/else
//statement
//condition ? expression : expression
int main(){
//int grade = 75;
//grade >=60 ? std::cout << "You pass!" : std::cout << "You fail!";


//int number = 8;
//number % 2 == 1 ? std::cout << "000" : std:: cout << "Even";

bool hungry = true ;

//hungry ? std::cout <<"Your are hungry" : std::cout << "Your full";
    //Another way to write tenary
std::cout << (hungry ? "Your are hungry!" : "Your are full!");
return 0;




}
